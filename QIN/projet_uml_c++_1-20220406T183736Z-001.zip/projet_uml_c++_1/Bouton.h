#ifndef BOUTON_H
#define BOUTON_H
#include "lcarte.h"
#include "donnees_borne.h"
#include "memoire_borne.h"
#include <iostream>

using namespace std;
class Bouton
{
public:
	void Bouton_initialiser();
	int Bouton_push();
};
#endif
